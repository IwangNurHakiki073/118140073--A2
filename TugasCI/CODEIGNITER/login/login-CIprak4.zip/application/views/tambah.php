<html>

<body>
	<font face="Courier New" font-size="30">
		<div class="Main">
			<div class="head">
				<form method="POST" action="<?= base_url('index.php/auth/tambahData'); ?>">
					<h2 class="text mb-5">Tambah Data</h2>
					<div class="form-group">
						<input type="text" class="form-control input-sm" placeholder="Deskripsi" name="deskripsi">
						<input type="hidden" name="role" value="admin">
					</div>
					<button type="submit" class="btn mt-3 form-control">Register</button>
				</form>
				</form>
			</div>
		</div>
	</font>
</body>

</html>