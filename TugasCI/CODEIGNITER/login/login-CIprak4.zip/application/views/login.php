<html>

<body>
	<font face="Courier New" font-size="30">
		<div class="Main">
			<div class="head">
				<form method="POST" action="<?= base_url('index.php/auth/loginProcess'); ?>">
					<h1 class="text mb-5">Login</h1>
					<div class="form-group">
						<input type="text" class="form-control input-sm" placeholder="Username" name="username">
					</div>
					<div class="form-group mt-4 mb-5">
						<input type="Password" class="form-control input-sm" placeholder="Password" name="pwd">
					</div>

					<button type="submit" class="btn mt-3 form-control">Login</button>

				</form>
			</div>
		</div>
	</font>
</body>

</html>