<html>

<body>
	<font face="Courier New" font-size="20">
		<div class="Main">
			<div class="head">
				<form method="POST" action="<?= base_url('index.php/auth/registration'); ?>">
					<h2 class="text mb-5">Register</h2>
					<div class="form-group">
						<input type="text" class="form-control input-sm" placeholder="Username" name="username">
					</div>

					<div class="form-group mt-4 mb-3">
						<input type="Password" class="form-control input-sm" placeholder="Password" name="pwd">
					</div>

					<div class="form-group mb-5">
						<select name="role" class="form-control input-sm">
							<option value="admin" selected>Admin</option>
							<option value="user1">User 1</option>
							<option value="user2">User 2</option>
						</select>

						<div class="form-check">
							<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
							<label class="form-check-label" for="defaultCheck1"></label>
						</div>
						<button type="submit" class="btn mt-3 form-control">Register</button>
				</form>
			</div>
		</div>
	</font>
</body>

</html>