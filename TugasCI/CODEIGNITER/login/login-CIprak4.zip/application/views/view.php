<html>

<head>
	<title>Insert</title>
</head>

<body>
	<font face="Courier New" font-size="20">
		<div class="container">
			<div class="row mt-2">
				<div class="coloum">
					| <a href="data" class="btn btn-success btn-sm p-2 mb-2">Tambah Data</a> |
					<a href="logout" class="btn btn-danger btn-sm p-2 ml-2"> LOGOUT</a> |
					<table class="table table-striped text-center">
						<br>
						<tr>
							<th>ID</th>
							<th>Deskripsi</th>
							<th>Aksi</th>
						</tr>

						<?php foreach ($data->result() as $nilai) : ?>
							<tr>
								<td><?= $nilai->id; ?></td>
								<td><?= $nilai->deskripsi; ?></td>
								<td> | <a href="update/<?= $nilai->id; ?>" class="btn btn-success btn-sm"> Update</a> |
									<a href="hapus/<?= $nilai->id; ?>" class="btn btn-danger btn-sm"> Delete </a> |
								</td>
							</tr>
						<?php endforeach; ?>

					</table>
				</div>
			</div>
		</div>
	</font>
</body>

</html>